import React from "react";
import Image from "next/image";

const Banner1 = () => {
  return (
    <div className="w-full 2xl:w-[85%] overflow-x-hidden flex items-center  relative ">
      <Image
        src="/assets/bannerimg.png"
        alt="banner background"
        height={100}
        width={100}
        className="w-full h-[290px] "
      />

      <div className="h-full w-full absolute top-[0px]  px-5 z-10">
        <Image
          src="/assets/Group 7305.svg"
          alt="banner background"
          height={1000}
          width={1000}
          className="w-full h-[290px] "
        />
      </div>

      <div className="absolute text-white top-[90px] w-full  left-58 z-20">
        <h1 className=" mb-3 text-xl">
          Explore over <strong className="text-[#FF6E04]">150K+ </strong>
          Products & Services with ease
        </h1>
        <div className="w-[530px] h-[40px] rounded-full relative  bg-white flex items-center ">
          <button></button>
          <input type="text" />

          {/* search and mic section */}

          <div className="flex items-center absolute right-1">
            <Image
              src="/assets/mic.png"
              alt="microphone"
              height={100}
              width={100}
              className="h-5 w-5 z-50"
            />
            <button className="bg-[#ff6E04] text-white capitalize relative text-sm  flex items-center justify-center gap-1 rounded-full px-4 py-1.5">
              search
              <Image
                src="/assets/search.png"
                alt="microphone"
                height={100}
                width={100}
                className="h-4 w-4 z-30"
              />
            </button>
          </div>
        </div>
      </div>

     
      <Image src="/assets/girlInBanner.png" alt="girl in banner" height={500} width={500} className="h-77 w-70 absolute z-30 top-[-18] right-70" />
       <div className="flex-col flex  text-white top-20 pr-20 absolute  right-[-20]"> <h1 className="text-[65px] font-bold">150 K+ </h1> <p className="absolute  top-20 left-2"> Registered Businesess</p></div>
    
    </div>
  );
};

export default Banner1;
