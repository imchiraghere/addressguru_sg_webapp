import React from "react";
import Image from "next/image";

const Header = () => {
  const logos = [
    {
      title: "to let",
      img: "/assets/toLet.png",
    },
    {
      title: "jobs",
      img: "/assets/jobs.png",
    },
    {
      title: "marketplace",
      img: "/assets/marketPlace.png",
    },
  ];

  return (
    <div
      className="h-[70px] z-50
     bg-white  w-full flex items-center justify-between px-7"
    >
      {/* left section */}
      <div className="flex items-center gap-15">
        <Image
          src="/assets/navLogo.png"
          alt="nav logo"
          height={500}
          width={500}
          className="h-[16px] w-[23.33px]"
        />

        <Image
          src="/assets/logopng 1.png"
          alt="nav logo"
          height={500}
          width={500}
          className="h-[40px] w-[150px]"
        />
      </div>
      {/* right section */}
      <div className="flex items-center gap-10">
        {/* 3 cards type section */}

        <div className="flex gap-5 max-md:hidden">
          {logos.map((item, index) => (
            <div
              key={index}
              className="flex items-center text-xs w-12 flex-col gap-1"
            >
              <Image
                src={item.img}
                alt={item.title}
                height={100}
                width={100}
                className="h-[20px] w-[25px]"
              />
              <p className="capitalize font-semibold  text-[#4B4B4B]">
                {item.title}
              </p>
            </div>
          ))}
        </div>

        {/* button section */}
        <div className="flex items-center gap-5 font-bold">
          <button className="border-2 max-md:hidden border-[#EE7630] text-[#EE7630] px-3 py-1.5 rounded-lg capitalize">
            post free ads +
          </button>
          <button className="uppercase px-4 py-2 bg-[#0040FF] text-white rounded-xl ">
            login
          </button>
        </div>
      </div>
    </div>
  );
};

export default Header;
